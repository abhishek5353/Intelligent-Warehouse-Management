import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import { Header } from './components/Layout/Header';
import { HomePage } from './pages/HomePage';
import { DetectionPage } from './pages/DetectionPage';
import { TrackingPage } from './pages/TrackingPage';
import { HistoryPage } from './pages/HistoryPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'detection':
        return <DetectionPage />;
      case 'tracking':
        return <TrackingPage onNavigate={handleNavigate} />;
      case 'history':
        return <HistoryPage />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <AppProvider>
      <div className="min-h-screen bg-background">
        <Header currentPage={currentPage} onNavigate={handleNavigate} />
        <main className="flex-1">
          {renderCurrentPage()}
        </main>
      </div>
    </AppProvider>
  );
}