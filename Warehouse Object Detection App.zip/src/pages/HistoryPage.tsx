import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Calendar, Search, Filter, Download, Trash2, Package } from 'lucide-react';
import { generateMockHistory } from '../utils/api';

export function HistoryPage() {
  const { state, dispatch } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [selectedEvents, setSelectedEvents] = useState<Set<string>>(new Set());

  // Load mock history if empty
  const loadMockHistory = () => {
    const mockEvents = generateMockHistory(50);
    mockEvents.forEach(event => {
      dispatch({ type: 'ADD_TO_HISTORY', payload: event });
    });
  };

  // Filter and search logic
  const filteredEvents = useMemo(() => {
    let filtered = state.detectionHistory;

    // Text search
    if (searchTerm) {
      filtered = filtered.filter(event =>
        event.objects.some(obj => 
          obj.label.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }

    // Object type filter
    if (filterType !== 'all') {
      filtered = filtered.filter(event =>
        event.objects.some(obj => obj.label === filterType)
      );
    }

    // Date filter
    if (dateFilter !== 'all') {
      const now = new Date();
      const filterDate = new Date();
      
      switch (dateFilter) {
        case 'today':
          filterDate.setHours(0, 0, 0, 0);
          break;
        case 'week':
          filterDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          filterDate.setMonth(now.getMonth() - 1);
          break;
      }
      
      filtered = filtered.filter(event =>
        new Date(event.timestamp) >= filterDate
      );
    }

    return filtered;
  }, [state.detectionHistory, searchTerm, filterType, dateFilter]);

  // Get unique object types for filter dropdown
  const objectTypes = useMemo(() => {
    const types = new Set<string>();
    state.detectionHistory.forEach(event => {
      event.objects.forEach(obj => types.add(obj.label));
    });
    return Array.from(types).sort();
  }, [state.detectionHistory]);

  const toggleEventSelection = (eventId: string) => {
    const newSelected = new Set(selectedEvents);
    if (newSelected.has(eventId)) {
      newSelected.delete(eventId);
    } else {
      newSelected.add(eventId);
    }
    setSelectedEvents(newSelected);
  };

  const exportSelected = () => {
    const selectedEventsData = filteredEvents.filter(event => 
      selectedEvents.has(event.id)
    );
    
    const dataStr = JSON.stringify(selectedEventsData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `warehouse-detections-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    
    URL.revokeObjectURL(url);
  };

  const clearHistory = () => {
    if (confirm('Are you sure you want to clear all detection history?')) {
      localStorage.removeItem('warehouseDetectionHistory');
      dispatch({ type: 'LOAD_HISTORY', payload: [] });
      setSelectedEvents(new Set());
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold">Detection History</h1>
          <p className="text-muted-foreground">
            Browse and analyze past detection events
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline">
            {filteredEvents.length} of {state.detectionHistory.length} events
          </Badge>
          <Badge variant="outline">
            {selectedEvents.size} selected
          </Badge>
        </div>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filters & Search</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search objects..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="Object type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All types</SelectItem>
                {objectTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">Last week</SelectItem>
                <SelectItem value="month">Last month</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={exportSelected}
                disabled={selectedEvents.size === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={clearHistory}
                disabled={state.detectionHistory.length === 0}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>
          
          {state.detectionHistory.length === 0 && (
            <div className="text-center py-4">
              <Button onClick={loadMockHistory} variant="outline">
                Load Sample Data
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* History Grid */}
      {filteredEvents.length === 0 ? (
        <Card>
          <CardContent className="text-center py-16">
            <Package className="h-16 w-16 mx-auto mb-4 opacity-30" />
            <h3 className="text-lg font-medium mb-2">No detection events found</h3>
            <p className="text-muted-foreground mb-4">
              {state.detectionHistory.length === 0 
                ? "No detection history available. Start detecting objects to build your history."
                : "Try adjusting your search filters."}
            </p>
            {state.detectionHistory.length === 0 && (
              <Button onClick={loadMockHistory} variant="outline">
                Load Sample Data
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEvents.map((event) => (
            <Card 
              key={event.id}
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedEvents.has(event.id) ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => toggleEventSelection(event.id)}
            >
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">
                      {new Date(event.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  <Badge variant="secondary">
                    {event.objects.length} objects
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  {new Date(event.timestamp).toLocaleTimeString()}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-3">
                {/* Event snapshot */}
                {event.imageSnapshot && (
                  <div className="aspect-video bg-muted rounded-lg overflow-hidden">
                    <img 
                      src={event.imageSnapshot} 
                      alt="Detection snapshot"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                {/* Object list */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium">Detected Objects:</h4>
                  <div className="flex flex-wrap gap-1">
                    {event.objects.slice(0, 6).map((obj, index) => (
                      <Badge 
                        key={index} 
                        variant="outline" 
                        className="text-xs"
                      >
                        {obj.label} {(obj.confidence * 100).toFixed(0)}%
                      </Badge>
                    ))}
                    {event.objects.length > 6 && (
                      <Badge variant="secondary" className="text-xs">
                        +{event.objects.length - 6} more
                      </Badge>
                    )}
                  </div>
                </div>
                
                {/* Statistics */}
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                  <div>
                    Avg. Confidence: {
                      Math.round(
                        event.objects.reduce((sum, obj) => sum + obj.confidence, 0) / 
                        event.objects.length * 100
                      )
                    }%
                  </div>
                  <div>
                    Types: {new Set(event.objects.map(obj => obj.label)).size}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Summary Statistics */}
      {filteredEvents.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Summary Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-500">
                  {filteredEvents.length}
                </div>
                <p className="text-sm text-muted-foreground">Total Events</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-500">
                  {filteredEvents.reduce((sum, event) => sum + event.objects.length, 0)}
                </div>
                <p className="text-sm text-muted-foreground">Objects Detected</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-500">
                  {new Set(filteredEvents.flatMap(event => event.objects.map(obj => obj.label))).size}
                </div>
                <p className="text-sm text-muted-foreground">Unique Types</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-500">
                  {Math.round(
                    filteredEvents.reduce((sum, event) => 
                      sum + event.objects.reduce((objSum, obj) => objSum + obj.confidence, 0) / event.objects.length, 0
                    ) / filteredEvents.length * 100
                  )}%
                </div>
                <p className="text-sm text-muted-foreground">Avg. Confidence</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}