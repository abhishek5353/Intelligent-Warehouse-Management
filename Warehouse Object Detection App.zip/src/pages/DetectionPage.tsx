import React, { useEffect, useRef } from 'react';
import { useAppContext } from '../context/AppContext';
import { VideoFeed } from '../components/Detection/VideoFeed';
import { DetectionPanel } from '../components/Detection/DetectionPanel';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Play, Square, Camera, Settings } from 'lucide-react';
import { detectObjects } from '../utils/api';

export function DetectionPage() {
  const { state, dispatch } = useAppContext();
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const startDetection = () => {
    dispatch({ type: 'START_DETECTION' });
    
    // Start detection loop
    detectionIntervalRef.current = setInterval(async () => {
      try {
        const detections = await detectObjects();
        dispatch({ type: 'UPDATE_DETECTIONS', payload: detections });
        
        // Add to history if objects were detected
        if (detections.length > 0) {
          const event = {
            id: `event_${Date.now()}`,
            timestamp: new Date().toISOString(),
            objects: detections,
          };
          dispatch({ type: 'ADD_TO_HISTORY', payload: event });

          // Update tracking data if tracking is enabled
          if (state.trackingEnabled) {
            detections.forEach(detection => {
              dispatch({
                type: 'UPDATE_TRACKED_OBJECT',
                payload: { id: detection.label, detection }
              });
            });
          }
        }
      } catch (error) {
        console.error('Detection error:', error);
      }
    }, 1000);
  };

  const stopDetection = () => {
    dispatch({ type: 'STOP_DETECTION' });
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current);
      detectionIntervalRef.current = null;
    }
  };

  const toggleTracking = () => {
    dispatch({ type: 'TOGGLE_TRACKING' });
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current);
      }
    };
  }, []);

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold">Object Detection</h1>
          <p className="text-muted-foreground">
            Real-time object detection and identification
          </p>
        </div>
        
        {/* Status Badges */}
        <div className="flex flex-wrap gap-2">
          <Badge variant={state.isDetecting ? "default" : "secondary"}>
            {state.isDetecting ? "Detecting" : "Standby"}
          </Badge>
          <Badge variant={state.trackingEnabled ? "default" : "outline"}>
            Tracking {state.trackingEnabled ? "On" : "Off"}
          </Badge>
          <Badge variant="outline">
            {state.currentDetections.length} Objects
          </Badge>
        </div>
      </div>

      {/* Control Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <span>Detection Controls</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {!state.isDetecting ? (
              <Button 
                onClick={startDetection}
                className="bg-green-600 hover:bg-green-700"
              >
                <Play className="mr-2 h-4 w-4" />
                Start Detection
              </Button>
            ) : (
              <Button 
                onClick={stopDetection}
                variant="destructive"
              >
                <Square className="mr-2 h-4 w-4" />
                Stop Detection
              </Button>
            )}
            
            <Button 
              onClick={toggleTracking}
              variant={state.trackingEnabled ? "default" : "outline"}
            >
              <Camera className="mr-2 h-4 w-4" />
              {state.trackingEnabled ? "Disable" : "Enable"} Tracking
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Detection Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Video Feed */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Camera className="h-5 w-5" />
                <span>Live Video Feed</span>
                {state.isDetecting && (
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-sm text-green-500">Live</span>
                  </div>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <VideoFeed 
                detections={state.currentDetections}
                isActive={state.isDetecting}
              />
            </CardContent>
          </Card>
        </div>

        {/* Detection Panel */}
        <div className="lg:col-span-1">
          <DetectionPanel detections={state.currentDetections} />
        </div>
      </div>

      {/* Detection Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Detection Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">
              {state.isDetecting ? '1.0 Hz' : '0 Hz'}
            </div>
            <p className="text-sm text-muted-foreground">Detections per second</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Confidence Avg</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-500">
              {state.currentDetections.length > 0 
                ? Math.round(state.currentDetections.reduce((sum, d) => sum + d.confidence, 0) / state.currentDetections.length * 100)
                : 0}%
            </div>
            <p className="text-sm text-muted-foreground">Average confidence</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Object Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-500">
              {new Set(state.currentDetections.map(d => d.label)).size}
            </div>
            <p className="text-sm text-muted-foreground">Unique object types</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}