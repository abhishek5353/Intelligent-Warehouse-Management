import React from 'react';
import { useAppContext } from '../context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Eye, 
  Activity, 
  History, 
  Package, 
  TrendingUp, 
  Clock,
  AlertTriangle,
  CheckCircle 
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const { state } = useAppContext();

  const stats = [
    {
      title: 'Objects Detected Today',
      value: state.detectionHistory.filter(event => {
        const today = new Date().toDateString();
        return new Date(event.timestamp).toDateString() === today;
      }).reduce((sum, event) => sum + event.objects.length, 0),
      icon: Package,
      color: 'text-blue-500',
      change: '+12%'
    },
    {
      title: 'Active Detections',
      value: state.currentDetections.length,
      icon: Eye,
      color: 'text-green-500',
      change: 'Live'
    },
    {
      title: 'Tracking Sessions',
      value: state.trackedObjects.size,
      icon: Activity,
      color: 'text-orange-500',
      change: `${state.trackingEnabled ? 'Active' : 'Inactive'}`
    },
    {
      title: 'Detection Events',
      value: state.detectionHistory.length,
      icon: History,
      color: 'text-purple-500',
      change: 'All time'
    }
  ];

  const recentDetections = state.detectionHistory.slice(0, 5);

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-foreground">
          Intelligent Warehouse Management
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Real-time object detection and tracking system for modern warehouse operations.
          Monitor, detect, and track inventory with advanced AI-powered vision.
        </p>
        <div className="flex justify-center space-x-4">
          <Button 
            size="lg" 
            onClick={() => onNavigate('detection')}
            className="bg-yellow-500 hover:bg-yellow-600 text-black"
          >
            <Eye className="mr-2 h-5 w-5" />
            Start Detection
          </Button>
          <Button 
            variant="outline" 
            size="lg"
            onClick={() => onNavigate('tracking')}
          >
            <Activity className="mr-2 h-5 w-5" />
            View Tracking
          </Button>
        </div>
      </div>

      {/* Statistics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                {stat.change}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* System Status and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span>System Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Detection Engine</span>
              <Badge variant={state.isDetecting ? "default" : "secondary"}>
                {state.isDetecting ? "Active" : "Standby"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Object Tracking</span>
              <Badge variant={state.trackingEnabled ? "default" : "secondary"}>
                {state.trackingEnabled ? "Enabled" : "Disabled"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Data Storage</span>
              <Badge variant="default">Operational</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Camera Feed</span>
              <Badge variant="default">Connected</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-500" />
              <span>Recent Activity</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentDetections.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <AlertTriangle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No recent activity</p>
                <p className="text-sm">Start detection to see activity</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentDetections.map((event, index) => (
                  <div 
                    key={event.id}
                    className="flex items-center justify-between p-3 border border-border rounded-lg"
                  >
                    <div>
                      <p className="font-medium">
                        {event.objects.length} object{event.objects.length !== 1 ? 's' : ''} detected
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(event.timestamp).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex space-x-1">
                      {event.objects.slice(0, 3).map((obj, objIndex) => (
                        <Badge key={objIndex} variant="outline" className="text-xs">
                          {obj.label}
                        </Badge>
                      ))}
                      {event.objects.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{event.objects.length - 3}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
                <Button 
                  variant="ghost" 
                  className="w-full" 
                  onClick={() => onNavigate('history')}
                >
                  View All Activity
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              variant="outline" 
              className="h-20 flex flex-col space-y-2"
              onClick={() => onNavigate('detection')}
            >
              <Eye className="h-6 w-6" />
              <span>Object Detection</span>
            </Button>
            <Button 
              variant="outline" 
              className="h-20 flex flex-col space-y-2"
              onClick={() => onNavigate('tracking')}
            >
              <Activity className="h-6 w-6" />
              <span>3D Tracking</span>
            </Button>
            <Button 
              variant="outline" 
              className="h-20 flex flex-col space-y-2"
              onClick={() => onNavigate('history')}
            >
              <History className="h-6 w-6" />
              <span>View History</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}