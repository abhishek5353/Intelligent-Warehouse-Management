import React from 'react';
import { useAppContext } from '../context/AppContext';
import { WarehouseScene } from '../components/Tracking/WarehouseScene';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Activity, Map, Settings, Eye } from 'lucide-react';

interface TrackingPageProps {
  onNavigate: (page: string) => void;
}

export function TrackingPage({ onNavigate }: TrackingPageProps) {
  const { state, dispatch } = useAppContext();

  const toggleTracking = () => {
    dispatch({ type: 'TOGGLE_TRACKING' });
  };

  const trackingData = Array.from(state.trackedObjects.entries()).map(([id, positions]) => ({
    id,
    label: positions[positions.length - 1]?.label || 'Unknown',
    positionCount: positions.length,
    lastSeen: positions[positions.length - 1]?.timestamp || 'Never',
    currentPosition: positions[positions.length - 1]?.position3D,
    confidence: positions[positions.length - 1]?.confidence || 0,
  }));

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold">3D Object Tracking</h1>
          <p className="text-muted-foreground">
            Real-time 3D visualization and tracking of warehouse objects
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Badge variant={state.trackingEnabled ? "default" : "secondary"}>
            Tracking {state.trackingEnabled ? "Active" : "Inactive"}
          </Badge>
          <Badge variant="outline">
            {trackingData.length} Tracked Objects
          </Badge>
          <Badge variant="outline">
            {state.currentDetections.length} Live Detections
          </Badge>
        </div>
      </div>

      {/* Control Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <span>Tracking Controls</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button 
              onClick={toggleTracking}
              variant={state.trackingEnabled ? "destructive" : "default"}
            >
              <Activity className="mr-2 h-4 w-4" />
              {state.trackingEnabled ? "Disable" : "Enable"} Tracking
            </Button>
            
            <Button 
              onClick={() => onNavigate('detection')}
              variant="outline"
            >
              <Eye className="mr-2 h-4 w-4" />
              Switch to Detection
            </Button>
            
            {!state.isDetecting && (
              <div className="text-sm text-muted-foreground flex items-center">
                Start detection to see real-time tracking data
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 3D Warehouse View */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        <div className="xl:col-span-3">
          <Card className="h-96">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Map className="h-5 w-5" />
                <span>3D Warehouse View</span>
                {state.trackingEnabled && (
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    <span className="text-sm text-blue-500">Tracking</span>
                  </div>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 h-80">
              <WarehouseScene 
                detections={state.currentDetections}
                trackedObjects={state.trackedObjects}
              />
            </CardContent>
          </Card>
        </div>

        {/* Tracking Statistics */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Active Objects</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-500">
                {state.currentDetections.length}
              </div>
              <p className="text-sm text-muted-foreground">Currently visible</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Tracked Paths</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-500">
                {trackingData.length}
              </div>
              <p className="text-sm text-muted-foreground">Total tracked objects</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Data Points</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-500">
                {trackingData.reduce((sum, obj) => sum + obj.positionCount, 0)}
              </div>
              <p className="text-sm text-muted-foreground">Position recordings</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Tracking Data Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5" />
            <span>Tracking Data</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {trackingData.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              <Activity className="h-12 w-12 mx-auto mb-4 opacity-30" />
              <p>No tracking data available</p>
              <p className="text-sm">Enable tracking and start detection to see data</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Object Type</TableHead>
                  <TableHead>Position Data</TableHead>
                  <TableHead>Current Location</TableHead>
                  <TableHead>Confidence</TableHead>
                  <TableHead>Last Seen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {trackingData.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">{item.label}</Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">
                        {item.positionCount} points
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {item.currentPosition ? (
                        <span className="text-sm font-mono">
                          ({item.currentPosition.x.toFixed(1)}, {item.currentPosition.z.toFixed(1)})
                        </span>
                      ) : (
                        <span className="text-muted-foreground">Unknown</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <div 
                          className={`w-2 h-2 rounded-full ${
                            item.confidence > 0.8 ? 'bg-green-500' : 
                            item.confidence > 0.6 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                        />
                        <span>{(item.confidence * 100).toFixed(0)}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">
                        {new Date(item.lastSeen).toLocaleTimeString()}
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* 3D View Controls Info */}
      <Card>
        <CardHeader>
          <CardTitle>3D View Controls</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <h4 className="font-medium mb-2">Mouse Controls</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Left click + drag: Rotate view</li>
                <li>• Right click + drag: Pan view</li>
                <li>• Scroll: Zoom in/out</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Object Legend</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Yellow cubes: Current detections</li>
                <li>• Faded trails: Movement history</li>
                <li>• Gray areas: Warehouse aisles</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">View Information</h4>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Scale: 1 unit = 1 meter</li>
                <li>• Objects float for visibility</li>
                <li>• Red zones: Equipment areas</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}