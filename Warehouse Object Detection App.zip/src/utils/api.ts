import { DetectedObject } from '../context/AppContext';

// Mock object classes that might be found in a warehouse
const OBJECT_CLASSES = [
  'box', 'pallet', 'forklift', 'person', 'package', 'container', 
  'cart', 'barrel', 'crate', 'equipment'
];

// Generate random bounding box coordinates
function generateBoundingBox() {
  const x = Math.random() * 0.6 + 0.1; // 10% to 70% of screen width
  const y = Math.random() * 0.6 + 0.1; // 10% to 70% of screen height
  const width = Math.random() * 0.2 + 0.1; // 10% to 30% width
  const height = Math.random() * 0.2 + 0.1; // 10% to 30% height
  
  return { x, y, width, height };
}

// Generate 3D position for warehouse tracking
function generate3DPosition() {
  return {
    x: Math.random() * 20 - 10, // -10 to 10 meters
    y: 0, // Ground level
    z: Math.random() * 15 - 7.5 // -7.5 to 7.5 meters
  };
}

// Mock API function to simulate object detection
export async function detectObjects(videoFrame?: Blob): Promise<DetectedObject[]> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 200 + Math.random() * 300));
  
  // Randomly generate 0-5 detected objects
  const numObjects = Math.floor(Math.random() * 6);
  const detections: DetectedObject[] = [];
  
  for (let i = 0; i < numObjects; i++) {
    const detection: DetectedObject = {
      id: `obj_${Date.now()}_${i}`,
      label: OBJECT_CLASSES[Math.floor(Math.random() * OBJECT_CLASSES.length)],
      confidence: 0.5 + Math.random() * 0.5, // 50% to 100% confidence
      bbox: generateBoundingBox(),
      timestamp: new Date().toISOString(),
      position3D: generate3DPosition(),
    };
    
    detections.push(detection);
  }
  
  return detections;
}

// Mock API function to get warehouse layout data
export async function getWarehouseLayout() {
  return {
    width: 20, // meters
    depth: 15, // meters
    height: 8, // meters
    aisles: [
      { x: -6, z: -5, width: 2, depth: 10 },
      { x: -2, z: -5, width: 2, depth: 10 },
      { x: 2, z: -5, width: 2, depth: 10 },
      { x: 6, z: -5, width: 2, depth: 10 },
    ],
    obstacles: [
      { x: -8, z: 6, width: 3, depth: 2, height: 2, type: 'equipment' },
      { x: 8, z: 6, width: 3, depth: 2, height: 2, type: 'equipment' },
    ]
  };
}

// Generate mock historical data
export function generateMockHistory(count: number = 20) {
  const events = [];
  const now = Date.now();
  
  for (let i = 0; i < count; i++) {
    const timestamp = new Date(now - (i * 1000 * 60 * 30)).toISOString(); // 30 min intervals
    const numObjects = Math.floor(Math.random() * 4) + 1;
    const objects: DetectedObject[] = [];
    
    for (let j = 0; j < numObjects; j++) {
      objects.push({
        id: `hist_${timestamp}_${j}`,
        label: OBJECT_CLASSES[Math.floor(Math.random() * OBJECT_CLASSES.length)],
        confidence: 0.6 + Math.random() * 0.4,
        bbox: generateBoundingBox(),
        timestamp,
        position3D: generate3DPosition(),
      });
    }
    
    events.push({
      id: `event_${timestamp}`,
      timestamp,
      objects,
      imageSnapshot: `data:image/svg+xml;base64,${btoa(`<svg width="200" height="150" xmlns="http://www.w3.org/2000/svg"><rect width="200" height="150" fill="#1a202c"/><text x="100" y="75" text-anchor="middle" fill="#ffc107" font-family="sans-serif">Snapshot ${i + 1}</text></svg>`)}`,
    });
  }
  
  return events;
}