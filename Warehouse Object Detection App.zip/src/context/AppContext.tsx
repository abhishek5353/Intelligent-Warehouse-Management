import React, { createContext, useContext, useReducer, useEffect } from 'react';

export interface DetectedObject {
  id: string;
  label: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  timestamp: string;
  position3D?: {
    x: number;
    y: number;
    z: number;
  };
}

export interface DetectionEvent {
  id: string;
  timestamp: string;
  objects: DetectedObject[];
  imageSnapshot?: string;
}

interface AppState {
  isDetecting: boolean;
  currentDetections: DetectedObject[];
  detectionHistory: DetectionEvent[];
  trackingEnabled: boolean;
  trackedObjects: Map<string, DetectedObject[]>;
}

type AppAction =
  | { type: 'START_DETECTION' }
  | { type: 'STOP_DETECTION' }
  | { type: 'UPDATE_DETECTIONS'; payload: DetectedObject[] }
  | { type: 'ADD_TO_HISTORY'; payload: DetectionEvent }
  | { type: 'TOGGLE_TRACKING' }
  | { type: 'UPDATE_TRACKED_OBJECT'; payload: { id: string; detection: DetectedObject } }
  | { type: 'LOAD_HISTORY'; payload: DetectionEvent[] };

const initialState: AppState = {
  isDetecting: false,
  currentDetections: [],
  detectionHistory: [],
  trackingEnabled: false,
  trackedObjects: new Map(),
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'START_DETECTION':
      return { ...state, isDetecting: true };
    
    case 'STOP_DETECTION':
      return { ...state, isDetecting: false, currentDetections: [] };
    
    case 'UPDATE_DETECTIONS':
      return { ...state, currentDetections: action.payload };
    
    case 'ADD_TO_HISTORY':
      const newHistory = [action.payload, ...state.detectionHistory].slice(0, 100); // Keep last 100 events
      localStorage.setItem('warehouseDetectionHistory', JSON.stringify(newHistory));
      return { ...state, detectionHistory: newHistory };
    
    case 'TOGGLE_TRACKING':
      return { ...state, trackingEnabled: !state.trackingEnabled };
    
    case 'UPDATE_TRACKED_OBJECT':
      const newTrackedObjects = new Map(state.trackedObjects);
      const existingTrack = newTrackedObjects.get(action.payload.id) || [];
      existingTrack.push(action.payload.detection);
      if (existingTrack.length > 50) existingTrack.shift(); // Keep last 50 positions
      newTrackedObjects.set(action.payload.id, existingTrack);
      return { ...state, trackedObjects: newTrackedObjects };
    
    case 'LOAD_HISTORY':
      return { ...state, detectionHistory: action.payload };
    
    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load history from localStorage on mount
  useEffect(() => {
    const savedHistory = localStorage.getItem('warehouseDetectionHistory');
    if (savedHistory) {
      try {
        const history = JSON.parse(savedHistory);
        dispatch({ type: 'LOAD_HISTORY', payload: history });
      } catch (error) {
        console.error('Failed to load detection history:', error);
      }
    }
  }, []);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}