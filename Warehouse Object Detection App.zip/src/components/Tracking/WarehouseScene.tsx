import React, { useRef } from 'react';
import { Canvas, useFrame, MeshProps } from '@react-three/fiber';
import { OrbitControls, Box, Plane, Text } from '@react-three/drei';
import { DetectedObject } from '../../context/AppContext';

interface TrackedObjectProps {
  detection: DetectedObject;
  trail?: DetectedObject[];
}

function TrackedObject({ detection, trail = [] }: TrackedObjectProps) {
  const meshRef = useRef<any>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      // Gentle floating animation
      meshRef.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.1 + 0.5;
    }
  });

  const getObjectColor = (label: string) => {
    const colors: Record<string, string> = {
      box: '#FFC107',
      pallet: '#8B4513',
      forklift: '#FF5722',
      person: '#2196F3',
      package: '#4CAF50',
      container: '#9C27B0',
      cart: '#FF9800',
      barrel: '#795548',
      crate: '#607D8B',
      equipment: '#E91E63',
    };
    return colors[label] || '#FFC107';
  };

  if (!detection.position3D) return null;

  const { x, z } = detection.position3D;
  const color = getObjectColor(detection.label);

  return (
    <group>
      {/* Main object */}
      <Box
        ref={meshRef}
        position={[x, 0.5, z]}
        args={[0.8, 1, 0.8]}
      >
        <meshStandardMaterial color={color} />
      </Box>
      
      {/* Object label */}
      <Text
        position={[x, 2, z]}
        fontSize={0.3}
        color="white"
        anchorX="center"
        anchorY="middle"
      >
        {detection.label}
      </Text>

      {/* Trail visualization */}
      {trail.length > 1 && (
        <group>
          {trail.slice(-10).map((trailPoint, index) => {
            if (!trailPoint.position3D) return null;
            const opacity = (index + 1) / trail.length;
            return (
              <Box
                key={`${trailPoint.id}-${index}`}
                position={[trailPoint.position3D.x, 0.1, trailPoint.position3D.z]}
                args={[0.2, 0.2, 0.2]}
              >
                <meshStandardMaterial 
                  color={color} 
                  transparent 
                  opacity={opacity * 0.5} 
                />
              </Box>
            );
          })}
        </group>
      )}
    </group>
  );
}

function WarehouseFloor() {
  return (
    <group>
      {/* Main floor */}
      <Plane
        rotation={[-Math.PI / 2, 0, 0]}
        args={[20, 15]}
        position={[0, 0, 0]}
      >
        <meshStandardMaterial color="#2D3748" />
      </Plane>

      {/* Aisle markers */}
      {[-6, -2, 2, 6].map((x, index) => (
        <group key={index}>
          <Box position={[x, 0.01, 0]} args={[2, 0.02, 10]}>
            <meshStandardMaterial color="#4A5568" />
          </Box>
          <Text
            position={[x, 0.1, -6]}
            rotation={[-Math.PI / 2, 0, 0]}
            fontSize={0.5}
            color="#A0AEC0"
            anchorX="center"
          >
            Aisle {index + 1}
          </Text>
        </group>
      ))}

      {/* Equipment areas */}
      <Box position={[-8, 1, 6]} args={[3, 2, 2]}>
        <meshStandardMaterial color="#E53E3E" opacity={0.7} transparent />
      </Box>
      <Box position={[8, 1, 6]} args={[3, 2, 2]}>
        <meshStandardMaterial color="#E53E3E" opacity={0.7} transparent />
      </Box>

      {/* Wall boundaries */}
      <Box position={[0, 2, -7.5]} args={[20, 4, 0.1]}>
        <meshStandardMaterial color="#1A202C" />
      </Box>
      <Box position={[0, 2, 7.5]} args={[20, 4, 0.1]}>
        <meshStandardMaterial color="#1A202C" />
      </Box>
      <Box position={[-10, 2, 0]} args={[0.1, 4, 15]}>
        <meshStandardMaterial color="#1A202C" />
      </Box>
      <Box position={[10, 2, 0]} args={[0.1, 4, 15]}>
        <meshStandardMaterial color="#1A202C" />
      </Box>
    </group>
  );
}

interface WarehouseSceneProps {
  detections: DetectedObject[];
  trackedObjects: Map<string, DetectedObject[]>;
}

export function WarehouseScene({ detections, trackedObjects }: WarehouseSceneProps) {
  return (
    <div className="h-full w-full bg-slate-900">
      <Canvas
        camera={{ position: [15, 10, 15], fov: 60 }}
        shadows
      >
        <ambientLight intensity={0.4} />
        <pointLight position={[10, 10, 10]} intensity={0.8} castShadow />
        <pointLight position={[-10, 10, -10]} intensity={0.4} />
        
        <WarehouseFloor />
        
        {/* Current detections */}
        {detections.map((detection) => (
          <TrackedObject
            key={detection.id}
            detection={detection}
            trail={trackedObjects.get(detection.id)}
          />
        ))}
        
        <OrbitControls
          enablePan={true}
          enableZoom={true}
          enableRotate={true}
          maxPolarAngle={Math.PI / 2}
          minDistance={5}
          maxDistance={50}
        />
      </Canvas>
    </div>
  );
}