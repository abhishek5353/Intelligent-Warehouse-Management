import React from 'react';
import { useAppContext } from '../../context/AppContext';
import { Package, Activity, Eye, History } from 'lucide-react';
import { Button } from '../ui/button';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const { state } = useAppContext();

  const navItems = [
    { id: 'home', label: 'Home', icon: Package },
    { id: 'detection', label: 'Detection', icon: Eye },
    { id: 'tracking', label: 'Tracking', icon: Activity },
    { id: 'history', label: 'History', icon: History },
  ];

  return (
    <header className="bg-card border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Title */}
          <div className="flex items-center space-x-3">
            <div className="bg-yellow-500 p-2 rounded-lg">
              <Package className="h-6 w-6 text-black" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-foreground">WarehouseVision</h1>
              <p className="text-sm text-muted-foreground">Intelligent Object Detection</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex items-center space-x-2">
            {navItems.map(({ id, label, icon: Icon }) => (
              <Button
                key={id}
                variant={currentPage === id ? "default" : "ghost"}
                onClick={() => onNavigate(id)}
                className="flex items-center space-x-2"
              >
                <Icon className="h-4 w-4" />
                <span className="hidden sm:inline">{label}</span>
              </Button>
            ))}
          </nav>

          {/* Status Indicator */}
          <div className="flex items-center space-x-4">
            {state.isDetecting && (
              <div className="flex items-center space-x-2 text-green-500">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-sm">Detecting</span>
              </div>
            )}
            {state.trackingEnabled && (
              <div className="flex items-center space-x-2 text-blue-500">
                <Activity className="h-4 w-4" />
                <span className="text-sm">Tracking</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}