import React, { useRef, useEffect, useState } from 'react';
import { DetectionCanvas } from './DetectionCanvas';
import { DetectedObject } from '../../context/AppContext';
import { Card } from '../ui/card';
import { Alert, AlertDescription } from '../ui/alert';
import { Camera } from 'lucide-react';

interface VideoFeedProps {
  detections: DetectedObject[];
  isActive: boolean;
}

export function VideoFeed({ detections, isActive }: VideoFeedProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [videoDimensions, setVideoDimensions] = useState({ width: 640, height: 480 });

  useEffect(() => {
    if (!isActive) return;

    const startVideo = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 1280, height: 720 }
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setVideoError(null);
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        setVideoError('Unable to access camera. Using demo mode.');
      }
    };

    startVideo();

    return () => {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isActive]);

  const handleVideoLoad = () => {
    if (videoRef.current) {
      setVideoDimensions({
        width: videoRef.current.videoWidth || 640,
        height: videoRef.current.videoHeight || 480
      });
    }
  };

  if (!isActive) {
    return (
      <Card className="aspect-video bg-muted flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <Camera className="h-16 w-16 mx-auto mb-4" />
          <p>Video feed inactive</p>
          <p className="text-sm">Start detection to begin</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="relative overflow-hidden">
      {videoError ? (
        <div className="aspect-video bg-slate-800 relative">
          <Alert className="absolute top-4 left-4 right-4 z-10">
            <AlertDescription>{videoError}</AlertDescription>
          </Alert>
          {/* Demo pattern */}
          <div className="w-full h-full bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center">
            <div className="text-white/20 text-6xl">📦</div>
          </div>
          <DetectionCanvas
            detections={detections}
            videoWidth={videoDimensions.width}
            videoHeight={videoDimensions.height}
          />
        </div>
      ) : (
        <div className="relative aspect-video">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
            onLoadedMetadata={handleVideoLoad}
          />
          <DetectionCanvas
            detections={detections}
            videoWidth={videoDimensions.width}
            videoHeight={videoDimensions.height}
          />
        </div>
      )}
    </Card>
  );
}