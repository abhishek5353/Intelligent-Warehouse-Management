import React, { useRef, useEffect } from 'react';
import { DetectedObject } from '../../context/AppContext';

interface DetectionCanvasProps {
  detections: DetectedObject[];
  videoWidth: number;
  videoHeight: number;
  className?: string;
}

export function DetectionCanvas({ detections, videoWidth, videoHeight, className }: DetectionCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw bounding boxes and labels
    detections.forEach((detection) => {
      const { bbox, label, confidence } = detection;
      
      // Convert relative coordinates to canvas coordinates
      const x = bbox.x * canvas.width;
      const y = bbox.y * canvas.height;
      const width = bbox.width * canvas.width;
      const height = bbox.height * canvas.height;

      // Set styling based on confidence
      const alpha = Math.max(0.6, confidence);
      const color = confidence > 0.8 ? '#4CAF50' : confidence > 0.6 ? '#FFC107' : '#F44336';

      // Draw bounding box
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.globalAlpha = alpha;
      ctx.strokeRect(x, y, width, height);

      // Draw label background
      const labelText = `${label} ${(confidence * 100).toFixed(0)}%`;
      ctx.font = '14px Arial';
      const textMetrics = ctx.measureText(labelText);
      const labelWidth = textMetrics.width + 8;
      const labelHeight = 20;

      ctx.fillStyle = color;
      ctx.globalAlpha = 0.8;
      ctx.fillRect(x, y - labelHeight, labelWidth, labelHeight);

      // Draw label text
      ctx.fillStyle = '#000000';
      ctx.globalAlpha = 1;
      ctx.fillText(labelText, x + 4, y - 6);

      // Draw center point
      ctx.fillStyle = color;
      ctx.globalAlpha = alpha;
      ctx.beginPath();
      ctx.arc(x + width / 2, y + height / 2, 3, 0, 2 * Math.PI);
      ctx.fill();
    });

    // Reset global alpha
    ctx.globalAlpha = 1;
  }, [detections, videoWidth, videoHeight]);

  return (
    <canvas
      ref={canvasRef}
      width={videoWidth}
      height={videoHeight}
      className={`absolute inset-0 pointer-events-none ${className}`}
      style={{ width: '100%', height: '100%' }}
    />
  );
}