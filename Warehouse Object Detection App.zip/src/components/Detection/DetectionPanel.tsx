import React from 'react';
import { DetectedObject } from '../../context/AppContext';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Package, Clock } from 'lucide-react';

interface DetectionPanelProps {
  detections: DetectedObject[];
}

export function DetectionPanel({ detections }: DetectionPanelProps) {
  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'bg-green-500';
    if (confidence >= 0.6) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getConfidenceVariant = (confidence: number) => {
    if (confidence >= 0.8) return 'default';
    if (confidence >= 0.6) return 'secondary';
    return 'destructive';
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Package className="h-5 w-5" />
          <span>Detected Objects</span>
          <Badge variant="outline">{detections.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {detections.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            <Package className="h-12 w-12 mx-auto mb-4 opacity-30" />
            <p>No objects detected</p>
            <p className="text-sm">Objects will appear here when detected</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {detections.map((detection, index) => (
              <div
                key={detection.id}
                className="p-3 border border-border rounded-lg bg-card"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${getConfidenceColor(detection.confidence)}`} />
                    <span className="font-medium capitalize">{detection.label}</span>
                  </div>
                  <Badge variant={getConfidenceVariant(detection.confidence)}>
                    {(detection.confidence * 100).toFixed(0)}%
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>Confidence</span>
                    <span>{(detection.confidence * 100).toFixed(1)}%</span>
                  </div>
                  <Progress 
                    value={detection.confidence * 100} 
                    className="h-2"
                  />
                  
                  <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>{new Date(detection.timestamp).toLocaleTimeString()}</span>
                  </div>
                  
                  {detection.position3D && (
                    <div className="text-xs text-muted-foreground">
                      Position: ({detection.position3D.x.toFixed(1)}, {detection.position3D.z.toFixed(1)})
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}