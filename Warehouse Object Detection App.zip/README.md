
  # Warehouse Object Detection App

  This is a code bundle for Warehouse Object Detection App. The original project is available at https://www.figma.com/design/MZKpgngP1rY4mU4YvScW9b/Warehouse-Object-Detection-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  